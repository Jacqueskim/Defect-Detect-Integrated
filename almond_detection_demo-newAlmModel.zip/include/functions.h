#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void object_detected(float x, float y);

#endif /* FUNCTIONS_H */
